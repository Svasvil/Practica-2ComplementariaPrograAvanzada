﻿using CasoPractico1.Abstracciones.LogicaDeNegocios.Habitaciones.AgregarHabitacon;
using CasoPractico1.Abstracciones.LogicaDeNegocios.Habitaciones.EditarHabitacion;
using CasoPractico1.Abstracciones.LogicaDeNegocios.Habitaciones.HabitacionPorId;
using CasoPractico1.Abstracciones.LogicaDeNegocios.Habitaciones.ListadoHabitacion;
using CasoPractico1.Abstracciones.LogicaDeNegocios.Habitaciones.ListarReservaPorHabitacion;
using CasoPractico1.Abstracciones.ModelosParaUI.Habitaciones;
using CasoPractico1.LogicaDeNegocio.Habitaciones.AgregarHabitacion;
using CasoPractico1.LogicaDeNegocio.Habitaciones.EditarHabitacion;
using CasoPractico1.LogicaDeNegocio.Habitaciones.HabitacionPorId;
using CasoPractico1.LogicaDeNegocio.Habitaciones.ListadoHabitacion;
using CasoPractico1.LogicaDeNegocio.Habitaciones.ListarReservaPorHabitacion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CasoPractico1.Controllers
{
    public class HabitacionesController : Controller
    {
        private readonly IListadoHabitacionLN _obtenerLaListaDeHabitacionesLN;
        private readonly IHabitacionPorIdLN _obtenerHabitacionPorIdLN;
        private readonly IAgregarHabitacionLN _agregarHabitacionLN;
        private readonly IEditarHabitacionLN _editarHabitacionLN;
        private readonly IListarReservaPorHabitacionLN _listarReservaPorHabitacionLN;

        public HabitacionesController()
        {
            _obtenerLaListaDeHabitacionesLN = new ListadoHabitacionLN();
            _obtenerHabitacionPorIdLN = new HabitacionPorIdLN();
            _agregarHabitacionLN = new AgregarHabitacionLN();
            _editarHabitacionLN = new EditarHabitacionLN();
            _listarReservaPorHabitacionLN = new ListarReservaPorHabitacionLN();
        }
        // GET: Habitaciones
        public ActionResult Index()
        {
            List<HabitacionesDto> laListaDeHabitaciones = _obtenerLaListaDeHabitacionesLN.Obtener();
            return View(laListaDeHabitaciones);
        }

        // GET: Habitaciones/Details/5
        public ActionResult Details(int Id_Habitacion)
        {
            List<ReservaAdministrativaDto> laListaDeReservas = _listarReservaPorHabitacionLN.Obtener(Id_Habitacion);
            return View(laListaDeReservas);
        }

        // GET: Habitaciones/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Habitaciones/Create
        [HttpPost]
        public async Task<ActionResult> Create(HabitacionesDto laHabitacionParaGuardar)
        {
            try
            {
                // TODO: Add insert logic here

                int cantidadDeFilasAfectadas = await _agregarHabitacionLN.Agregar(laHabitacionParaGuardar);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Habitaciones/Edit/5
        public ActionResult Edit(int idDelaHabitacionABuscar)
        {
            HabitacionesDto laHabitacionEnBaseDeDatos = _obtenerHabitacionPorIdLN.Obtener(idDelaHabitacionABuscar);
            return View(laHabitacionEnBaseDeDatos);
        }

        // POST: Habitaciones/Edit/5
        [HttpPost]
        public ActionResult Edit(int idDelaHabitacionABuscar, HabitacionesDto laHabitacionParaGuardar)
        {
            try
            {
                // TODO: Add update logic here
                int cantidadDeFilasAfectadas = _editarHabitacionLN.Editar(laHabitacionParaGuardar);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Habitaciones/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Habitaciones/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
