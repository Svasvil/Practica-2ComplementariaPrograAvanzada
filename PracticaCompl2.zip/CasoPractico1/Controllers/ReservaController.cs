﻿using CasoPractico1.Abstracciones.LogicaDeNegocios.Habitaciones.ListadoHabitacion;
using CasoPractico1.Abstracciones.LogicaDeNegocios.Reserva.AgregarReserva;
using CasoPractico1.Abstracciones.LogicaDeNegocios.Reserva.ListarReserva;
using CasoPractico1.Abstracciones.LogicaDeNegocios.Reserva.ListarReservaPorId;
using CasoPractico1.Abstracciones.ModelosParaUI.Habitaciones;
using CasoPractico1.LogicaDeNegocio.Reserva.AgregarReserva;
using CasoPractico1.LogicaDeNegocio.Reserva.ListarReserva;
using CasoPractico1.LogicaDeNegocio.Reserva.ListarReservaPorId;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CasoPractico1.Controllers
{
    public class ReservaController : Controller
    {
        private readonly IListarReservaLN _obtenerLaListaDeReservasLN;
        private readonly IListarReservaPorIdLN _obtenerLalistaReservaPorIdLN;
        private readonly IAgregarReservaLN _AgregarReservaLN;

        public ReservaController()
        {
            _obtenerLaListaDeReservasLN = new ListarReservaLN();
            _obtenerLalistaReservaPorIdLN = new ListarReservaPorIdLN();
            _AgregarReservaLN = new AgregarReservaLN();
        }

        // GET: Reserva
        public ActionResult Index()
        {
            List<HabitacionesDto> laListaDeHabitaciones = _obtenerLaListaDeReservasLN.Obtener();
            return View(laListaDeHabitaciones);
        }

        // GET: Reserva/Details/5
        public ActionResult Details(int idDeLaReservaABuscar)
        {
            var laReservaEnBaseDeDatos = _obtenerLalistaReservaPorIdLN.Obtener(idDeLaReservaABuscar);

            if (laReservaEnBaseDeDatos == null)
            {
                TempData["Mensaje"] = "No se encontró ninguna reserva con ese ID.";
                return RedirectToAction("Index");
            }

            // Configurar para abrir el modal automáticamente
            TempData["AbrirModal"] = true;
            TempData["IdReserva"] = idDeLaReservaABuscar;

            return View(laReservaEnBaseDeDatos);
        }

        public ActionResult DetallesPartialView(int idDeLaReservaABuscar)
        {
            var laReservaEnBaseDeDatos = _obtenerLalistaReservaPorIdLN.Obtener(idDeLaReservaABuscar);

            if (laReservaEnBaseDeDatos == null)
            {
                TempData["Mensaje"] = "No se encontró ninguna reserva con ese ID.";
                return RedirectToAction("Index");
            }

            return PartialView("_DetallesPartialView", laReservaEnBaseDeDatos);
        }

        // GET: Reserva/Create
        public ActionResult Create(int id_habitacion, decimal p_costoreserva, decimal p_costolimpieza)
        {
            var modelo = new ReservaAdministrativaDto
            {
                IdHabitacion = id_habitacion,
                CostoDeReserva = p_costoreserva,
                CostoDeLimpieza = p_costolimpieza
            };

            return View(modelo);
        }

        // POST: Reserva/Create
        [HttpPost]
        public async Task<ActionResult> Create(ReservaAdministrativaDto laReservaParaGuardar)
        {
            try
            {
                int idReservaGuardada = await _AgregarReservaLN.Agregar(laReservaParaGuardar, laReservaParaGuardar.IdHabitacion);

                if (idReservaGuardada > 0)
                {
                    TempData["Mensaje"] = "La reserva se guardó correctamente.";
                    return RedirectToAction("Details", new { idDeLaReservaABuscar = idReservaGuardada });
                }

                ViewBag.Mensaje = "No se pudo guardar la reserva.";
                return View(laReservaParaGuardar);
            }
            catch (Exception ex)
            {
                var error = ex.InnerException?.InnerException?.Message ?? ex.InnerException?.Message ?? ex.Message;
                ViewBag.Mensaje = "Error al guardar la reserva: " + error;
                System.Diagnostics.Debug.WriteLine(ex.ToString());
                return View(laReservaParaGuardar);
            }
        }

        // GET: Reserva/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Reserva/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Reserva/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Reserva/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}