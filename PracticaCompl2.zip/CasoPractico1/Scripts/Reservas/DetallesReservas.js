﻿$(document).ready(function () {

    function cargarModal(idReserva) {
        $.ajax({
            url: '/Reservas/DetallesPartialView',
            type: "GET",
            data: { idDeLaReservaABuscar: idReserva },
            success: function (Respuesta) {
                $('#exampleModal .modal-body').html(Respuesta);

                // Crear instancia de Bootstrap 5 Modal y mostrar
                const modalEl = document.getElementById('exampleModal');
                const modal = new bootstrap.Modal(modalEl);
                modal.show();
            },
            error: function (xhr, status, error) {
                alert('Error al cargar el modal: ' + error);
            }
        });
    }

    // Obtener ID de la URL
    const urlParams = new URLSearchParams(window.location.search);
    const idReserva = urlParams.get('idDeLaReservaABuscar');

    if (idReserva) {
        cargarModal(idReserva); // esto abrirá el modal automáticamente
    }

    // Funcionalidad del botón manual (si quieres mantenerlo)
    $("[data-bs-toggle='modal'][data-bs-target='#exampleModal']").click(function () {
        let idReservaBoton = $(this).data('id-reserva');
        cargarModal(idReservaBoton);
    });

    $("#exampleModal .btn-primary").click(function () {
        Swal.fire({
            title: "Guardado exitoso!",
            icon: "success",
            draggable: true
        });
    });

});
